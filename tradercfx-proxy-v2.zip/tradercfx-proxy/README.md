# TraderCFX Proxy — Panduan Deploy ke Vercel

## Isi Folder Ini
```
tradercfx-proxy/
├── api/
│   └── chat.js       ← kode proxy (jangan diubah)
├── vercel.json       ← konfigurasi Vercel
├── package.json      ← info project
└── README.md         ← panduan ini
```

---

## LANGKAH DEPLOY

### Step 1 — Upload ke GitHub
1. Buka github.com → login
2. Klik tombol "+" → "New repository"
3. Nama repo: `tradercfx-proxy`
4. Pilih "Public" → klik "Create repository"
5. Upload semua file di folder ini ke repo tersebut

### Step 2 — Deploy ke Vercel
1. Buka vercel.com → login pakai GitHub
2. Klik "Add New Project"
3. Pilih repo `tradercfx-proxy`
4. Klik "Deploy" — tunggu selesai

### Step 3 — Masukkan API Key (PENTING!)
1. Di dashboard Vercel → masuk ke project kamu
2. Klik tab "Settings"
3. Klik "Environment Variables"
4. Tambah variable baru:
   - NAME  : ANTHROPIC_API_KEY
   - VALUE : sk-ant-api03-xxxx... (API key kamu)
5. Klik "Save"
6. Klik "Redeploy" agar perubahan aktif

### Step 4 — Catat URL kamu
Setelah deploy, Vercel akan kasih URL seperti:
```
https://tradercfx-proxy.vercel.app
```
URL endpoint proxy kamu adalah:
```
https://tradercfx-proxy.vercel.app/api/chat
```
Kirim URL ini ke developer untuk dipasang di app HTML.

---

## Selesai! 🎉
API key kamu tersimpan aman di Vercel, tidak terlihat di browser.
